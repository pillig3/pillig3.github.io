/**
 * Settings.java
 * Camden Sikes and Peter Illig, Jun 5, 2017
 *
 * This is our Model in the MVC model. It contains all the user
 * settings used to generate images.
 */

package mandelbrot;

public class Settings {
    private double[] center;
    private double radius; // y-axis will be displayed from -(radius*i) to radius*i
    private int width;
    private int height;
    private int colorScheme;
    private int maxIterations;

    /**
     * Creates a Settings object with the default settings
     */
    public Settings(){
        center = new double[]{0,0};
        radius = 2;
        width = 890;
        height = 500;
        colorScheme = 0;
        maxIterations = 1000;
    }

    public double[] getCenter() {
        return center;
    }

    public void setCenter(double[] center) {
        this.center = center;
    }

    public int getColorScheme() {
        return colorScheme;
    }

    public void setColorScheme(int colorScheme) {
        this.colorScheme = colorScheme;
    }

    public int getMaxIterations() {
        return maxIterations;
    }

    public void setMaxIterations(int maxIterations) {
        this.maxIterations = maxIterations;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
