/**
 * Controller.java
 * Camden Sikes and Peter Illig, Jun 5, 2017
 *
 * This is our Controller in the MVC model. It takes user input and handles it.
 */

package mandelbrot;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.image.ImageView;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

public class Controller implements EventHandler<Event> {

    private Settings settings;
    private Mandelbrot mandelbrot;
    @FXML private ImageView mandelbrotImage;
    @FXML private TextField maxIterations;
    @FXML private TextField mandelbrotRadius;
    @FXML private TextField centerReal;
    @FXML private TextField centerI;
    @FXML private ComboBox<String> colorChoice;

    public Controller() {
        settings = new Settings();
        mandelbrot = new Mandelbrot(settings);
        mandelbrotImage = new ImageView(mandelbrot.getMandelbrotImage());
        colorChoice = new ComboBox<String>();
    }

    @Override
    public void handle(Event event) {
        String eventType = event.getEventType().getName();
        if(eventType.equals("MOUSE_CLICKED")) {
            MouseEvent mEvent = (MouseEvent) event;
            //zoom in
            double oneStep = (settings.getRadius()*2)/((double)settings.getHeight());
            double left = settings.getCenter()[0]-(settings.getWidth())/2*oneStep;
            double top = settings.getCenter()[1]+(settings.getHeight())/2*oneStep;
            settings.setRadius(settings.getRadius()*0.5);
            double x = mEvent.getX()*oneStep + left;
            double y = top - (mEvent.getY()-50)*oneStep;
            settings.setCenter(new double[]{x,y});
        }else if(eventType.equals("KEY_PRESSED")){
            KeyEvent kEvent = (KeyEvent) event;
            switch (kEvent.getCode()){
                case UP:
                case KP_UP:
                case W:
                    settings.setCenter(new double[]{settings.getCenter()[0],settings.getCenter()[1]+settings.getRadius()/4});
                    break;
                case DOWN:
                case KP_DOWN:
                case S:
                    settings.setCenter(new double[]{settings.getCenter()[0],settings.getCenter()[1]-settings.getRadius()/4});
                    break;
                case LEFT:
                case KP_LEFT:
                case A:
                    settings.setCenter(new double[]{settings.getCenter()[0]-settings.getRadius()/3,settings.getCenter()[1]});
                    break;
                case RIGHT:
                case KP_RIGHT:
                case D:
                    settings.setCenter(new double[]{settings.getCenter()[0]+settings.getRadius()/3,settings.getCenter()[1]});
                    break;
            }
        }
        update();
    }

    /*
     * Handles textbox input
     */
    public void onFieldChange(ActionEvent actionEvent) {
        String field = ((TextField) actionEvent.getSource()).getId();
        Double value;
        try{
            switch(field){
                case "centerReal":
                    value = Double.parseDouble(centerReal.getText());
                    settings.setCenter(new double[]{value,settings.getCenter()[1]});
                    break;
                case "centerI":
                    value = Double.parseDouble(centerI.getText());
                    settings.setCenter(new double[]{settings.getCenter()[0],value});
                    break;
                case "mandelbrotRadius":
                    value = Double.parseDouble(mandelbrotRadius.getText());
                    settings.setRadius(value);
                    break;
                case "maxIterations":
                    value = Double.parseDouble(maxIterations.getText());
                    settings.setMaxIterations(value.intValue());
                    break;
                default:
                    throw new NumberFormatException();
            }
        }
        catch (NumberFormatException e){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information Dialog");
            alert.setHeaderText(null);
            alert.setContentText("Please enter a number");
            alert.showAndWait();
            return;
        }
        update();
    }

    public void onSaveButtonPress(ActionEvent actionEvent) {
        TextInputDialog dialog = new TextInputDialog("enter filename");
        dialog.setTitle("Save Image");
        dialog.setHeaderText(null);
        dialog.setContentText("Please enter a filename (sans extension)");
        try {
            String filename = String.valueOf(dialog.showAndWait());
            System.out.println(filename);
            if(!filename.equals("Optional[]")) {
                filename = filename.substring(filename.indexOf('[')+1, filename.length()-1)+".png";
                File outputFile = new File(filename);
                BufferedImage bImage = SwingFXUtils.fromFXImage(mandelbrot.getMandelbrotImage(), null);
                ImageIO.write(bImage, "png", outputFile);
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("File could not be written. " + e);
        }
    }

    public void onZoomIn(ActionEvent actionEvent) {
        settings.setRadius(settings.getRadius()*0.5);
        update();
    }

    public void onZoomOut(ActionEvent actionEvent) {
        settings.setRadius(settings.getRadius()*2);
        update();
    }

    public void onColorChange(ActionEvent actionEvent) {
        switch(colorChoice.getValue()){
            case "Grayscale":
                settings.setColorScheme(0);
                break;
            case "Yellow":
                settings.setColorScheme(1);
                break;
            case "Purple":
                settings.setColorScheme(2);
                break;
            case "Red":
                settings.setColorScheme(3);
                break;
            case "Teal":
                settings.setColorScheme(4);
                break;
            case "Green":
                settings.setColorScheme(5);
                break;
            case "Blue":
                settings.setColorScheme(6);
                break;
            default:
                break;
        }
        update();
    }

    public Settings getSettings() {
        return settings;
    }

    public Mandelbrot getMandelbrot() {
        return mandelbrot;
    }

    public ImageView getMandelbrotImage() {
        return mandelbrotImage;
    }

    public void update() {
        mandelbrot.changeSettings(settings);
        mandelbrotImage.setImage(mandelbrot.getMandelbrotImage());
    }
}
