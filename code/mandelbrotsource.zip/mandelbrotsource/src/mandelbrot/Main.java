/**
 * Main.java
 * Camden Sikes and Peter Illig, Jun 5, 2017
 *
 * Main program for our Mandelbrot set viewer.
 */

package mandelbrot;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;
import java.io.IOException;

public class Main extends Application {

    public Main() throws IOException {
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });

        FXMLLoader loader = new FXMLLoader(getClass().getResource("mandelbrot.fxml"));
        GridPane root = loader.load();
        Controller controller = loader.getController();
        primaryStage.setTitle("Mandelbrot");
        Scene scene = new Scene(root, 890, 500);

        // listeners for resizing of window
        scene.widthProperty().addListener(new ChangeListener<Number>() {
            @Override public void changed(ObservableValue<? extends Number> observableValue, Number oldSceneWidth, Number newSceneWidth) {
                controller.getSettings().setWidth(newSceneWidth.intValue());
                controller.update();
            }
        });
        scene.heightProperty().addListener(new ChangeListener<Number>() {
            @Override public void changed(ObservableValue<? extends Number> observableValue, Number oldSceneHeight, Number newSceneHeight) {
                controller.getSettings().setHeight(newSceneHeight.intValue());
                controller.update();
            }
        });

        HBox pictureRegion = new HBox();
        pictureRegion.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                root.requestFocus();
            }
        });

        pictureRegion.getChildren().add(controller.getMandelbrotImage());
        root.add(pictureRegion, 0, 2, 14, 1);
        root.setOnMouseClicked(controller);
        root.setOnKeyPressed(controller);
        primaryStage.setScene(scene);
        primaryStage.show();
        root.requestFocus();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
