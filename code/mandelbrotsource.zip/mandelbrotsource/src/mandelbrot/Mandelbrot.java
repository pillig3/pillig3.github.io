/**
 * Mandelbrot.java
 * Camden Sikes and Peter Illig, Jun 5, 2017
 *
 * This is our View in the MVC model. It generates an image of the Mandelbrot set pixel-by-pixel,
 * according to the parameters in a Settings file.
 */

package mandelbrot;

import javafx.scene.image.Image;
import javafx.scene.image.PixelWriter;
import javafx.scene.paint.Color;
import javafx.scene.image.WritableImage;

public class Mandelbrot {
    private WritableImage mandelbrotImage;

    public Mandelbrot(Settings settings) {
        this.createMandelbrot(settings);
    }

    public void changeSettings(Settings settings) {
        this.createMandelbrot(settings);
    }

    /**
     * Generates the image based on the values in settings
     */
    public void createMandelbrot(Settings settings) {
        int width = settings.getWidth();
        int height = settings.getHeight();
        mandelbrotImage = new WritableImage(width, height);
        PixelWriter writer = mandelbrotImage.getPixelWriter();
        int max_iteration = settings.getMaxIterations();
        double[] center = settings.getCenter();
        double radius = settings.getRadius();
        double x0 = 0;
        double y0 = 0;
        double x = 0;
        double y = 0;
        double xTemp = 0;
        //set the user's color preferences
        float red = 1;
        float green = 1;
        float blue = 1;
        if(settings.getColorScheme() >= 4) {
            red = 0;
        }
        if(settings.getColorScheme() % 4 >= 2) {
            green = 0;
        }
        if(settings.getColorScheme() % 2 == 1) {
            blue = 0;
        }
        int iteration = 1;
        double oneStep = (radius*2)/((double)height); // the real distance that corresponds to moving one pixel

        x0 = center[0]-(width/2)*oneStep;
        for (int c=0; c<width; c++) {
            y0 = center[1]+(height/2)*oneStep;
            for (int r=0; r<height; r++) {
                writer.setColor(c,r,Color.BLACK);
                x = 0;
                y = 0;
                iteration = 1;
                while (x * x + y * y < 2 * 2 && iteration < max_iteration) {
                    xTemp = x * x - y * y + x0;
                    y = 2 * x * y + y0;
                    x = xTemp;
                    iteration++;
                }
                // set color of pixel based on current iteration
                if (iteration < max_iteration) {
                    float scaledValue = (float)Math.pow((double) iteration / ((double) max_iteration), 0.25);
                    Color color = Color.color(scaledValue*red,scaledValue*green,scaledValue*blue);
                    writer.setColor(c, r, color);
                }
                y0 -= oneStep;
            }
            x0 += oneStep;
        }
    }

    public Image getMandelbrotImage(){
        return mandelbrotImage;
    }
}
